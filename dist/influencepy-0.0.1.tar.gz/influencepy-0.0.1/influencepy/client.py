API_BASE_URL = 'https://api.influenceth.io'


class InfluenceClient:
    def __init__(self):
        pass
